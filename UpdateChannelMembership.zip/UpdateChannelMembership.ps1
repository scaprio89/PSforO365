﻿$UpdateChannel = Import-CSV -path "C:\Users\SteveCaprio\OneDrive - Daymark Solutions\Daymark Files\Office365 Content\Pega\TeamsScripting\NewTeamsCSV3.csv"

Foreach ($line in $UpdateChannel) { 

$Team = Get-Team -DisplayName $line.TeamDisplayName
$objGroup = Get-MsolGroup -SearchString "$($line.GroupAccess)"
write-host "Processing $($objGroup.DisplayName)..."  
$objGMembers = Get-MsolGroupMember -groupobjectid $($objGroup.objectid)    
  
 write-host "Found $($objGMembers.Count) members..."    
  
#$name = $objGMembers.objectid  
$displayname = $objGMembers.displayname  
$email = $objGMembers.proxyaddresses  
Foreach ($objMember in $objGMembers)    
    {    
   
    Add-TeamChannelUser -GroupId $Team.GroupID -displayname $line.PrivateChannel -User $objMember.EmailAddress
          
    write-host "User $($objMember.DisplayName) added to $($line.privatechannel) as a Member"   
    }  
#start-sleep 30
}
