$NewTeams = Import-CSV -path "C:\Daymark\NewTeams.csv"

Foreach ($line in $NewTeams) { 

$group = New-Team -MailNickname $line.MailNickname -displayname $line.DisplayName -Visibility $line.Visibility
Add-TeamUser -GroupId $group.GroupId -User $line.User1 -role Owner
#Add-TeamUser -GroupId $group.GroupID -User $line.User2 -role Owner
$GroupName = "$($line.DisplayName) $($line.Permissions)"
$objGroup = Get-MsolGroup -SearchString "$($line.GroupAccess)"
write-host "Processing $($objGroup.DisplayName)..."  
$objGMembers = Get-MsolGroupMember -groupobjectid $($objGroup.objectid)    
  
 write-host "Found $($objGMembers.Count) members..."    
  
#$name = $objGMembers.objectid  
$displayname = $objGMembers.displayname  
$email = $objGMembers.proxyaddresses  
Foreach ($objMember in $objGMembers)    
    {    
   
    Add-TeamUser -GroupId $group.GroupID -User $objMember.EmailAddress -role Member
          
    write-host "User $($objMember.DisplayName) added to $($objGroup.DisplayName) Team as a Member"   
    }  
#start-sleep 30
#Add-SPOUser -Site "https://pegasystems.sharepoint.com/sites/$($line.MailNickname)" -LoginName $line.GroupAccess -Group $GroupName

Remove-Variable groupname
}


