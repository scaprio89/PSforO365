$NewTeams = Import-CSV -path "C:\Users\SteveCaprio\OneDrive - Daymark Solutions\Daymark Files\Office365 Content\Pega\TeamsScripting\NewTeamsCSV2.csv"

Foreach ($line in $NewTeams) { 

$group = New-Team -MailNickname $line.MailNickname -displayname $line.DisplayName -Visibility $line.Visibility
Add-TeamUser -GroupId $group.GroupId -User $line.User1 -role Owner
#Add-TeamUser -GroupId $group.GroupID -User $line.User2 -role Owner
$objGroup = Get-MsolGroup -SearchString "$($line.GroupAccess)"
write-host "Processing $($objGroup.DisplayName)..."  
$objGMembers = Get-MsolGroupMember -groupobjectid $($objGroup.objectid)    
  
 write-host "Found $($objGMembers.Count) members..."    
  
#$name = $objGMembers.objectid  
$displayname = $objGMembers.displayname  
$email = $objGMembers.proxyaddresses  
Foreach ($objMember in $objGMembers)    
    {    
   
    Add-TeamUser -GroupId $group.GroupID -User $objMember.EmailAddress -role Member
          
    write-host "User $($objMember.DisplayName) added to $($line.DisplayName) Team as a Member"   
    }  
#start-sleep 30
}


